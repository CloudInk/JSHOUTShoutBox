$(document).ready(function(){
$('#loading').fadeIn(100);
$('#shoutbox').prepend("<li>Welcome to jShout v. 1 | a cloudink, inc. production</li>");
$('#shoutbox').prepend("<li>http://code.google.com/p/j-shout/</li>");
$('#shoutbox').prepend("<li>Loading....</li>");
$('#shoutbox').delay(2000).load('jShout_refresh.php');
$('#shoutbox').animate({scrollTop: $('#shoutbox').prop('scrollHeight') + $('#shoutbox').height() }, 1);
$('#pmb').load('jShout_messaging_request.php');
$('#pvt').load('jShout_messaging.php');
$('#cuser').load('jShout_user.php');
$('#history').load('jShout_history_refresh.php');
$('#loading').fadeOut(2800);
$('#shistory').live('click', function(){ 
$('#historylabel').html("<a href='javascript:void(0)' id='hhistory'>History -</A>");
$('#shoutbox').slideUp('slow');
$('#shoutform').fadeOut(50);
$('#history').delay(100).slideDown('slow');
});
$('#hhistory').live('click', function(){ 
$('#historylabel').html("<a href='javascript:void(0)' id='shistory'>History +</A>");
$('#history').slideUp('slow');
$('#shoutbox').slideDown('slow');
$('#shoutform').delay(500).fadeIn(100);
});
$('#shelp').live('click', function(){ 
$('#help').delay(200).fadeIn(900);
$('#helplabel').html("<a href='javascript:void(0)' id='hhelp'>Help -</A>");
});
$('#hhelp').live('click', function(){ 
$('#help').delay(200).fadeOut(900);
$('#helplabel').html("<a href='javascript:void(0)' id='shelp'>Help +</A>");
});
$('#msgs').live('click', function(){ 
$('#pmbox').delay(200).fadeIn(400);
});
$('#pmclose').live('click', function(){ 
$('#pmbox').delay(200).fadeOut(400);
});



$('#showid').live('click', function(){ 
$('#infobox').delay(200).fadeIn(200);
$('#infobox').html("<div id='infoheader'><div id='infocontainer'><div id='infoleft'>User Stats</div><div id='inforight'><a href='javascript:void(0)' id='infoclose'>close</a></div></div></div><li><div id='infocontainer'><div id='infoleft'>User:</div><div id='inforight'>crAyon</div></div></li><li><div id='infocontainer'><div id='infoleft'>Shouts:</div><div id='inforight'>317</div></div></li><li><div id='infocontainer'><div id='infoleft'>Last Seen:</div><div id='inforight'>99/99/9999</div></div></li><li><div id='infocontainer'><div id='infoleft'>Users Trolled:</div><div id='inforight'>12</div></div></li><li><div id='infocontainer'><div id='infoleft'>Member Since:</div><div id='inforight'>99/99/9999</div></div></li>");
});						

$('#infoclose').live('click', function(){ 
$('#infobox').delay(200).fadeOut(600);
});
$("#jshout").submit(function(event) { 
event.preventDefault(); 
$('input[name="sb"]').prop('disabled', true);
$('#loading').fadeIn(100);
var $form = $( this ),
sb = $form.find( 'input[name="sb"]' ).val(),
url = $form.attr( 'action' );
jshout = "v_01";
req = "add_shout";
if(sb == '') {
	$('#loading').fadeOut(100);
	$('input[name="sb"]').prop('disabled', false);
	return false;
}
$.post( url, {sb: sb, jshout: jshout, req: req },
function( data ) {
$('#shoutbox').append( "<li>" + data  + "</li>");
$('#history').prepend( "<li>" + data  + "</li>");
$('#shoutbox').animate({scrollTop: $('#shoutbox').prop('scrollHeight') - $('#shoutbox').height() }, 1);
$('input[name=sb]').val( '' );
$('input[name="sb"]').prop('disabled', false);
$('#loading').fadeOut(100);
});
});
});
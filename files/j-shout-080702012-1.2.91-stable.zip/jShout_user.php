<?php
$user = $_COOKIE['jShout'];
if($user) {
		$user = $_COOKIE['jShout'];
} else {
	$user = "Guest";
}

print "{$user}";

?>
